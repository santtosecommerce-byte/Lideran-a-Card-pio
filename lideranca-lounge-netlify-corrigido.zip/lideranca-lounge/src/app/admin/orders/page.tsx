"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { AdminShell } from "@/components/admin-shell";
import { currency } from "@/lib/utils";
import type { Order, OrderStatus } from "@/lib/orders";
import type { Call } from "@/lib/calls";

const COLUMNS: { status: OrderStatus; title: string }[] = [
  { status: "awaiting_payment", title: "Aguardando pagamento" },
  { status: "new", title: "Pagos · novos" },
  { status: "preparing", title: "Em preparo" },
  { status: "ready", title: "Prontos para entrega" }
];

const ACTIONS: Record<OrderStatus, { action: string; label: string; primary?: boolean }[]> = {
  awaiting_payment: [{ action: "confirm_payment", label: "Confirmar pagamento", primary: true }, { action: "cancel", label: "Cancelar" }],
  new: [{ action: "prepare", label: "Iniciar preparo", primary: true }, { action: "cancel", label: "Cancelar" }],
  preparing: [{ action: "ready", label: "Marcar pronto", primary: true }],
  ready: [{ action: "deliver", label: "Entregue na mesa", primary: true }],
  delivered: [],
  cancelled: []
};

export default function OrdersPage() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [calls, setCalls] = useState<Call[]>([]);
  const seenCalls = useRef<Set<string>>(new Set());
  const callsPrimed = useRef(false);
  const [alertsOn, setAlertsOn] = useState(false);
  const [error, setError] = useState("");
  const seen = useRef<Set<string>>(new Set());
  const primed = useRef(false);
  const audio = useRef<AudioContext | null>(null);
  const alertsRef = useRef(false);

  const beep = useCallback(() => {
    const ctx = audio.current;
    if (!ctx) return;
    [0, 0.35, 0.7].forEach(t => {
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.frequency.value = 880;
      g.gain.setValueAtTime(0.25, ctx.currentTime + t);
      g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + t + 0.3);
      o.connect(g).connect(ctx.destination);
      o.start(ctx.currentTime + t);
      o.stop(ctx.currentTime + t + 0.3);
    });
  }, []);

  const load = useCallback(async () => {
    try {
      const res = await fetch("/api/orders", { cache: "no-store" });
      if (res.status === 401) { window.location.href = "/login"; return; }
      const data = await res.json();
      const list: Order[] = data.orders ?? [];
      if (!primed.current) {
        list.forEach(o => seen.current.add(o.id));
        primed.current = true;
      } else {
        const fresh = list.filter(o => !seen.current.has(o.id) && (o.status === "awaiting_payment" || o.status === "new"));
        fresh.forEach(o => {
          seen.current.add(o.id);
          if (alertsRef.current) {
            beep();
            if ("Notification" in window && Notification.permission === "granted") {
              new Notification(`Novo pedido #${o.number}`, { body: `${o.tableName} · ${currency(o.totalCents / 100)}` });
            }
          }
        });
      }
      setOrders(list);

      const cres = await fetch("/api/calls", { cache: "no-store" });
      if (cres.ok) {
        const cdata = await cres.json();
        const openCallsList: Call[] = cdata.calls ?? [];
        if (!callsPrimed.current) {
          openCallsList.forEach(c => seenCalls.current.add(c.id));
          callsPrimed.current = true;
        } else {
          openCallsList.filter(c => !seenCalls.current.has(c.id)).forEach(c => {
            seenCalls.current.add(c.id);
            if (alertsRef.current) beep();
          });
        }
        setCalls(openCallsList);
      }
      setError("");
    } catch {
      setError("Sem conexão com o servidor. Tentando de novo…");
    }
  }, [beep]);

  useEffect(() => {
    load();
    const t = setInterval(load, 4000);
    return () => clearInterval(t);
  }, [load]);

  async function enableAlerts() {
    try {
      audio.current = new AudioContext();
      await audio.current.resume();
    } catch { /* sem áudio */ }
    if ("Notification" in window && Notification.permission === "default") {
      await Notification.requestPermission();
    }
    alertsRef.current = true;
    setAlertsOn(true);
    beep();
  }

  async function attend(id: string) {
    await fetch(`/api/calls/${id}`, { method: "PATCH" });
    load();
  }

  async function act(id: string, action: string) {
    const res = await fetch(`/api/orders/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action })
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) alert(data.error || "Não foi possível atualizar o pedido.");
    load();
  }

  const time = (iso: string) => new Date(iso).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });

  return (
    <AdminShell title="Pedidos" subtitle="Pedidos feitos pelo cardápio digital em tempo real.">
      <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
        <div className="text-xs text-[#8e8980]">{error || "Atualiza a cada 4 segundos"}</div>
        {alertsOn ? (
          <div className="rounded-full border border-emerald-400/30 px-3 py-2 text-[11px] text-emerald-300">● Avisos sonoros ativos</div>
        ) : (
          <button onClick={enableAlerts} className="rounded-full bg-gradient-to-b from-[#f3dda4] to-[#b98d43] px-4 py-2 text-xs font-semibold text-[#15120a]">Ativar som e avisos</button>
        )}
      </div>

      {calls.length > 0 && (
        <div className="mb-5 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
          {calls.map(c => (
            <div key={c.id} className="flex items-center justify-between gap-3 rounded-2xl border border-amber-400/40 bg-amber-400/10 p-4">
              <div>
                <div className="text-sm font-semibold text-amber-200">{c.tableName}</div>
                <div className="text-xs text-amber-100/80">{c.reason === "conta" ? "Pediu a conta" : "Chamou o garçom"}</div>
              </div>
              <button onClick={() => attend(c.id)} className="rounded-lg bg-gradient-to-b from-[#f3dda4] to-[#b98d43] px-3 py-2 text-[11px] font-semibold text-[#15120a]">Atendido</button>
            </div>
          ))}
        </div>
      )}

      <div className="grid gap-4 xl:grid-cols-4">
        {COLUMNS.map(col => {
          const list = orders.filter(o => o.status === col.status);
          return (
            <section key={col.status} className="min-h-[360px] rounded-2xl border border-[var(--line)] bg-[#111113] p-3">
              <div className="mb-3 flex items-center justify-between px-1">
                <h2 className="text-xs font-semibold">{col.title}</h2>
                <span className="rounded-full bg-white/[.06] px-2 py-1 text-[10px] text-[#aaa]">{list.length}</span>
              </div>
              <div className="space-y-3">
                {list.map(o => (
                  <article key={o.id} className="rounded-xl border border-[var(--line)] bg-[#19191b] p-4">
                    <div className="flex justify-between">
                      <span className="text-xs font-semibold">Pedido #{o.number}</span>
                      <span className="text-[10px] text-[#8e8980]">{time(o.createdAt)}</span>
                    </div>
                    <div className="mt-1 text-sm text-[#d7b778]">{o.tableName}{o.customerName && <span className="ml-2 text-xs text-[#8e8980]">{o.customerName}</span>}</div>
                    <div className="my-3 space-y-2 border-y border-[var(--line)] py-3">
                      {o.items.map(i => (
                        <div key={i.productId} className="flex justify-between text-xs text-[#c7c2b8]"><span>{i.quantity}× {i.name}</span><span>{currency(i.lineTotalCents / 100)}</span></div>
                      ))}
                      {o.note && <p className="text-[11px] text-[#d7b778]">Obs.: {o.note}</p>}
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-semibold">{currency(o.totalCents / 100)}</span>
                      <span className={`text-[10px] ${o.paymentStatus === "approved" ? "text-emerald-300" : "text-amber-300"}`}>{o.paymentStatus === "approved" ? "Pago no caixa" : "Pagamento pendente"}</span>
                    </div>
                    <div className="mt-3 flex flex-wrap gap-2">
                      {ACTIONS[o.status].map(a => (
                        <button key={a.action} onClick={() => act(o.id, a.action)}
                          className={`rounded-lg px-3 py-2 text-[11px] ${a.primary ? "bg-gradient-to-b from-[#f3dda4] to-[#b98d43] font-semibold text-[#15120a]" : "border border-[var(--line)] text-[#c7c2b8]"}`}>
                          {a.label}
                        </button>
                      ))}
                    </div>
                  </article>
                ))}
              </div>
            </section>
          );
        })}
      </div>
    </AdminShell>
  );
}
