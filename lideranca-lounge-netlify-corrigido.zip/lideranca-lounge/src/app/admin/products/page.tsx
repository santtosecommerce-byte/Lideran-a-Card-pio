import { AdminShell } from "@/components/admin-shell";
import { menu } from "@/lib/menu-data";
import { currency } from "@/lib/utils";
import { Plus, Search, SlidersHorizontal } from "lucide-react";

export default function ProductsPage() {
  const total = menu.reduce((n, c) => n + c.items.length, 0);
  return <AdminShell title="Cardápio" subtitle="Organize categorias, produtos, preços, adicionais e disponibilidade.">
    <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-[var(--line)] bg-[#141416] p-4"><div className="flex items-center gap-2 text-xs text-[#8a857c]"><Search size={15}/> {menu.length} categorias · {total} produtos</div><div className="flex gap-2"><button className="flex items-center gap-2 rounded-xl border border-[var(--line)] px-3 py-2 text-xs text-[#c7c2b8]"><SlidersHorizontal size={14}/> Categorias</button><button disabled className="flex items-center gap-2 rounded-xl bg-[#c6a15b] px-3 py-2 text-xs font-semibold text-[#17130d] opacity-70"><Plus size={14}/> Novo produto</button></div></div>
    <div className="mt-6 grid gap-5 md:grid-cols-2 xl:grid-cols-3">{menu.map(c => <section key={c.name} className="glow-card overflow-hidden rounded-2xl bg-[#131315]">
      <div className="border-b border-[var(--line)] px-5 py-4"><h2 className="font-display text-gold text-lg font-bold">{c.name}</h2>{c.description && <p className="mt-1 text-[11px] text-[#77736b]">{c.description}</p>}</div>
      <ul className="divide-y divide-[var(--line)]">{c.items.map(i => <li key={i.name} className="flex items-center justify-between gap-3 px-5 py-3 text-sm"><span>{i.name}</span><span className="font-medium text-[#e0c58c]">{currency(i.priceCents / 100)}</span></li>)}</ul>
    </section>)}</div>
    <p className="mt-6 text-[11px] text-[#77736b]">Lista transcrita do cardápio impresso. Rode <code>supabase/seed_menu.sql</code> no Supabase para gravar no banco.</p>
  </AdminShell>;
}
