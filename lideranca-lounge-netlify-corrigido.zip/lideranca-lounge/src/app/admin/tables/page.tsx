"use client";
import { useCallback, useEffect, useState } from "react";
import { AdminShell } from "@/components/admin-shell";
import { Armchair, ExternalLink } from "lucide-react";

type T = { number: number; name: string; token: string; active: boolean };

export default function TablesPage() {
  const [tables, setTables] = useState<T[]>([]);
  const [count, setCount] = useState("10");
  const [base, setBase] = useState("");
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    const res = await fetch("/api/tables", { cache: "no-store" });
    if (res.status === 401) { window.location.href = "/login"; return; }
    const data = await res.json();
    setTables(data.tables ?? []);
  }, []);

  useEffect(() => {
    setBase(process.env.NEXT_PUBLIC_APP_URL || window.location.origin);
    load();
  }, [load]);

  async function add() {
    const n = Number(count);
    setBusy(true);
    setMsg("");
    const res = await fetch("/api/tables", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ count: n })
    });
    const data = await res.json().catch(() => ({}));
    setBusy(false);
    if (!res.ok) { setMsg(data.error || "Não foi possível adicionar as mesas."); return; }
    setMsg(`${data.added} mesa(s) adicionada(s).`);
    load();
  }

  async function toggle(t: T) {
    await fetch(`/api/tables/${t.number}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ active: !t.active })
    });
    load();
  }

  const active = tables.filter(t => t.active).length;

  return (
    <AdminShell title="Mesas e QR Codes" subtitle="Adicione ou desative mesas. Cada mesa tem um link próprio para o QR Code.">
      <div className="mb-5 flex flex-wrap items-end gap-3 rounded-2xl border border-[var(--line)] bg-[#141416] p-4">
        <label className="flex flex-col gap-2 text-xs text-[#99958d]">
          Quantas mesas adicionar
          <input type="number" min={1} max={100} value={count} onChange={e => setCount(e.target.value)}
            className="w-32 rounded-xl border border-[var(--line)] bg-[#17171a] px-3 py-2 text-sm text-white outline-none" />
        </label>
        <button onClick={add} disabled={busy} className="rounded-xl bg-gradient-to-b from-[#f3dda4] to-[#b98d43] px-4 py-2.5 text-xs font-semibold text-[#15120a] disabled:opacity-50">
          {busy ? "Adicionando…" : "Adicionar mesas"}
        </button>
        <div className="ml-auto text-xs text-[#8e8980]">{active} ativas de {tables.length} cadastradas</div>
        {msg && <p className="w-full text-xs text-[#d7b778]">{msg}</p>}
      </div>

      <div className="mb-5 rounded-xl border border-amber-400/20 bg-amber-400/[.06] p-4 text-xs leading-5 text-amber-100/80">
        As mesas iniciais usam tokens de demonstração. As mesas novas recebem tokens aleatórios. Antes de imprimir os QR Codes, confira o link de cada mesa.
      </div>

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
        {tables.map(t => (
          <article key={t.number} className={`flex items-center justify-between gap-3 rounded-2xl border p-4 ${t.active ? "border-[var(--line)] bg-[#141416]" : "border-white/5 bg-[#111113] opacity-60"}`}>
            <div className="flex min-w-0 items-center gap-3">
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-[#c6a15b]/10 text-[#d7b778]"><Armchair size={19} /></div>
              <div className="min-w-0">
                <div className="text-sm font-semibold">{t.name}</div>
                <div className="mt-1 text-[10px] text-[#858078]">{t.active ? "Ativa" : "Desativada"}</div>
                {base && <a className="mt-1 flex max-w-[210px] items-center gap-1 truncate text-[10px] text-[#c6a15b]" href={`${base}/menu/${t.token}`}>
                  <ExternalLink size={10} />{`/menu/${t.token}`}
                </a>}
              </div>
            </div>
            <button onClick={() => toggle(t)} className="shrink-0 rounded-lg border border-[var(--line)] px-3 py-2 text-[11px] text-[#c7c2b8]">
              {t.active ? "Desativar" : "Ativar"}
            </button>
          </article>
        ))}
      </div>
    </AdminShell>
  );
}
