import { NextResponse } from "next/server";
import { resolveCall } from "@/lib/calls";

// PATCH: equipe marca o chamado como atendido (protegido pelo middleware).
export async function PATCH(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!resolveCall(id)) return NextResponse.json({ error: "Chamado não encontrado." }, { status: 404 });
  return NextResponse.json({ ok: true });
}
