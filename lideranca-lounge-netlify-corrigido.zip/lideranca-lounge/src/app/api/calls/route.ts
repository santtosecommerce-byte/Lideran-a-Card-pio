import { NextResponse } from "next/server";
import { createCall, openCalls } from "@/lib/calls";

// GET: equipe vê os chamados abertos (protegido pelo middleware).
export async function GET() {
  return NextResponse.json({ calls: openCalls() });
}

// POST: cliente chama o garçom ou pede a conta.
export async function POST(req: Request) {
  const body = await req.json().catch(() => null);
  if (!body || typeof body !== "object") return NextResponse.json({ error: "Chamado inválido." }, { status: 400 });
  const result = createCall(body.tableToken, body.reason);
  if (!result.ok) return NextResponse.json({ error: result.error }, { status: 400 });
  return NextResponse.json({ call: { id: result.value.id, reason: result.value.reason } }, { status: 201 });
}
