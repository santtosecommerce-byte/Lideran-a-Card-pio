import { NextResponse } from "next/server";
import { applyAction, getOrderPublic, type OrderAction } from "@/lib/orders";

const ACTIONS: OrderAction[] = ["confirm_payment", "prepare", "ready", "deliver", "cancel"];

// GET: cliente acompanha o status do próprio pedido (id é UUID, não listável).
export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const order = getOrderPublic(id);
  if (!order) return NextResponse.json({ error: "Pedido não encontrado." }, { status: 404 });
  return NextResponse.json({ order });
}

// PATCH: equipe avança o status do pedido (protegido pelo middleware).
export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const body = (await req.json().catch(() => ({}))) as { action?: unknown };
  if (typeof body.action !== "string" || !ACTIONS.includes(body.action as OrderAction)) {
    return NextResponse.json({ error: "Ação inválida." }, { status: 400 });
  }
  const result = applyAction(id, body.action as OrderAction);
  if (!result.ok) return NextResponse.json({ error: result.error }, { status: 409 });
  return NextResponse.json({ order: result.value });
}
