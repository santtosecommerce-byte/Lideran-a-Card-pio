import { NextResponse } from "next/server";
import { createOrder, listOrders } from "@/lib/orders";

// GET: painel da equipe (protegido pelo middleware).
export async function GET() {
  return NextResponse.json({ orders: listOrders() });
}

// POST: cliente cria pedido. Preços são calculados no servidor a partir do catálogo.
export async function POST(req: Request) {
  const body = await req.json().catch(() => null);
  if (!body || typeof body !== "object") return NextResponse.json({ error: "Pedido inválido." }, { status: 400 });
  const result = createOrder(body);
  if (!result.ok) return NextResponse.json({ error: result.error }, { status: 400 });
  const o = result.value;
  return NextResponse.json({ order: { id: o.id, number: o.number, totalCents: o.totalCents, status: o.status } }, { status: 201 });
}
