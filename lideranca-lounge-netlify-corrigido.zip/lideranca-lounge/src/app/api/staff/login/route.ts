import { NextResponse } from "next/server";
import { STAFF_COOKIE, makeSessionToken, safeEqual } from "@/lib/staff-auth";

export async function POST(req: Request) {
  const expected = process.env.STAFF_PASSWORD;
  if (!expected || !process.env.STAFF_SECRET) {
    return NextResponse.json({ error: "Configure STAFF_PASSWORD e STAFF_SECRET no servidor." }, { status: 500 });
  }
  const body = (await req.json().catch(() => ({}))) as { password?: unknown };
  if (typeof body.password !== "string" || !safeEqual(body.password, expected)) {
    return NextResponse.json({ error: "Senha incorreta." }, { status: 401 });
  }
  const res = NextResponse.json({ ok: true });
  res.cookies.set(STAFF_COOKIE, await makeSessionToken(), {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 60 * 60 * 12
  });
  return res;
}
