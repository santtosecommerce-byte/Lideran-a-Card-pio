import { NextRequest, NextResponse } from "next/server";
import { STAFF_COOKIE } from "@/lib/staff-auth";

export async function GET(req: NextRequest) {
  const res = NextResponse.redirect(new URL("/login", req.url));
  res.cookies.set(STAFF_COOKIE, "", { path: "/", maxAge: 0 });
  return res;
}
