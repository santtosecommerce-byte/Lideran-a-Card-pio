import { NextResponse } from "next/server";
import { setTableActive } from "@/lib/tables";

// PATCH: ativa ou desativa uma mesa (somente equipe).
export async function PATCH(req: Request, { params }: { params: Promise<{ number: string }> }) {
  const { number } = await params;
  const body = (await req.json().catch(() => ({}))) as { active?: unknown };
  if (typeof body.active !== "boolean") return NextResponse.json({ error: "Informe active: true ou false." }, { status: 400 });
  if (!setTableActive(Number(number), body.active)) return NextResponse.json({ error: "Mesa não encontrada." }, { status: 404 });
  return NextResponse.json({ ok: true });
}
