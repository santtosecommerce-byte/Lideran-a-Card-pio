import { NextResponse } from "next/server";
import { addTables, listTables } from "@/lib/tables";

// GET e POST são protegidos pelo middleware (somente equipe).
export async function GET() {
  return NextResponse.json({ tables: listTables() });
}

export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as { count?: unknown };
  const result = addTables(body.count);
  if (!result.ok) return NextResponse.json({ error: result.error }, { status: 400 });
  return NextResponse.json({ added: result.added }, { status: 201 });
}
