import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Liderança Lounge Bar | Gestão",
  description: "Painel de pedidos e cardápio digital do Liderança Lounge Bar.",
  icons: { icon: "/icon.png", apple: "/apple-touch-icon.png" }
};
export const viewport: Viewport = { themeColor: "#0b0b0c" };

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="pt-BR"><body>{children}</body></html>;
}
