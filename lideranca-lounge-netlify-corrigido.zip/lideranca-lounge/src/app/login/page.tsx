"use client";
import { useState } from "react";

export default function LoginPage() {
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    const res = await fetch("/api/staff/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ password })
    });
    const data = await res.json().catch(() => ({}));
    setLoading(false);
    if (!res.ok) { setError(data.error || "Não foi possível entrar."); return; }
    window.location.href = "/admin/orders";
  }

  return (
    <main className="flex min-h-screen items-center justify-center px-5">
      <form onSubmit={submit} className="w-full max-w-sm rounded-3xl border border-[#c6a15b]/25 bg-[#101012] p-7">
        <div className="text-center">
          <div className="font-display text-gold text-xl font-semibold tracking-[.18em]">LIDERANÇA</div>
          <div className="mt-1 text-[9px] tracking-[.35em] text-[#c6a15b]">LOUNGE BAR · EQUIPE</div>
        </div>
        <label className="mt-7 block text-xs text-[#99958d]">Senha da equipe</label>
        <input type="password" value={password} onChange={e => setPassword(e.target.value)} autoComplete="current-password"
          className="mt-2 w-full rounded-xl border border-[var(--line)] bg-[#17171a] px-4 py-3 text-base outline-none focus:border-[#c6a15b]/50" />
        {error && <p className="mt-3 text-xs text-red-300">{error}</p>}
        <button disabled={loading || !password} className="mt-5 w-full rounded-xl bg-gradient-to-b from-[#f3dda4] to-[#b98d43] py-3 font-semibold text-[#15120a] disabled:opacity-50">
          {loading ? "Entrando…" : "Entrar"}
        </button>
      </form>
    </main>
  );
}
