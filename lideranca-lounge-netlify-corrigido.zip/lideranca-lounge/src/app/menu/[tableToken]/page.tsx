import { categories } from "@/lib/catalog";
import { findTableByToken } from "@/lib/tables";
import { MenuClient } from "@/components/menu-client";

export const dynamic = "force-dynamic";

export default async function TableMenuPage({ params }: { params: Promise<{ tableToken: string }> }) {
  const { tableToken } = await params;
  const table = findTableByToken(tableToken);
  if (!table) {
    return (
      <main className="flex min-h-screen items-center justify-center px-5 text-center">
        <div>
          <h1 className="font-display text-2xl">QR Code não encontrado</h1>
          <p className="mt-3 text-sm text-[#99958d]">Confira o código da mesa ou chame a equipe.</p>
        </div>
      </main>
    );
  }
  return <MenuClient table={{ number: table.number, name: table.name, token: table.token }} categories={categories} />;
}
