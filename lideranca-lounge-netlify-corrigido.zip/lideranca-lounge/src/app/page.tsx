import { AdminShell } from "@/components/admin-shell";
import { StatCard } from "@/components/stat-card";
import { orders, tables } from "@/lib/mock-data";
import { currency } from "@/lib/utils";
import { ArrowUpRight, Banknote, ClipboardList, Clock3, Armchair, MoreHorizontal } from "lucide-react";

export default function DashboardPage() {
  const active = orders.filter(o => o.status !== "Entregue");
  return <AdminShell title="Visão geral" subtitle="Acompanhe a operação e os pedidos do seu lounge em um só lugar.">
    <div className="mb-7 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-[#c6a15b]/20 bg-[linear-gradient(100deg,rgba(198,161,91,.12),rgba(198,161,91,.025))] p-5">
      <div><div className="text-xs text-[#c6a15b]">QUINTA-FEIRA · OPERAÇÃO</div><div className="font-display mt-2 text-xl font-medium">Uma noite excelente começa com um bom atendimento.</div><div className="mt-1 text-xs text-[#9b968b]">Painel demonstrativo — conecte o Supabase para dados reais.</div></div>
      <div className="flex items-center gap-2 rounded-full border border-[#c6a15b]/30 px-3 py-2 text-[11px] text-[#e0c58c]"><span className="h-2 w-2 rounded-full bg-[#c6a15b]"/> Sistema visualizando dados de exemplo</div>
    </div>
    <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
      <StatCard label="Pedidos hoje" value="38" note="+12% em relação ao período anterior" icon={ClipboardList}/>
      <StatCard label="Faturamento demonstrativo" value="R$ 2.480" note="Valores ilustrativos" icon={Banknote}/>
      <StatCard label="Pedidos em andamento" value={String(active.length).padStart(2,"0")} note="Aguardando preparo ou entrega" icon={Clock3}/>
      <StatCard label="Mesas cadastradas" value="15" note={`${tables.filter(t=>t.state==="Com pedidos").length} com pedidos na amostra`} icon={Armchair}/>
    </section>
    <section className="mt-9 grid gap-6 xl:grid-cols-[1.5fr_1fr]">
      <div className="overflow-hidden rounded-2xl border border-[var(--line)] bg-[#131315]">
        <div className="flex items-center justify-between border-b border-[var(--line)] px-5 py-4"><div><h2 className="text-sm font-semibold">Pedidos recentes</h2><p className="mt-1 text-[11px] text-[#77736b]">Últimas movimentações demonstrativas</p></div><a href="/admin/orders" className="flex items-center gap-1 text-xs text-[#d7b778]">Ver pedidos <ArrowUpRight size={14}/></a></div>
        <div className="divide-y divide-[var(--line)]">{orders.slice(0,4).map(o=><div key={o.id} className="flex flex-wrap items-center justify-between gap-3 px-5 py-4"><div><div className="text-xs font-semibold">Pedido #{o.id} <span className="ml-2 font-normal text-[#77736b]">{o.table}</span></div><div className="mt-1 text-[11px] text-[#88847c]">{o.items.map(i=>`${i.quantity}x ${i.name}`).join(" · ")}</div></div><div className="text-right"><div className="text-sm font-medium">{currency(o.total)}</div><span className={`mt-1 inline-flex rounded-full px-2 py-1 text-[10px] ${o.status==="Novo"?"bg-amber-400/10 text-amber-300":o.status==="Em preparo"?"bg-blue-400/10 text-blue-300":o.status==="Pronto"?"bg-emerald-400/10 text-emerald-300":"bg-white/5 text-[#aaa]"}`}>{o.status}</span></div></div>)}</div>
      </div>
      <div className="rounded-2xl border border-[var(--line)] bg-[#131315] p-5">
        <div className="flex items-center justify-between"><div><h2 className="text-sm font-semibold">Mapa de mesas</h2><p className="mt-1 text-[11px] text-[#77736b]">15 mesas cadastradas</p></div><MoreHorizontal size={18} className="text-[#77736b]"/></div>
        <div className="mt-5 grid grid-cols-3 gap-2 sm:grid-cols-5 xl:grid-cols-3 2xl:grid-cols-5">{tables.map(t=><div key={t.number} className={`rounded-xl border p-3 text-center ${t.state==="Com pedidos"?"border-[#c6a15b]/30 bg-[#c6a15b]/[.08]":"border-[var(--line)] bg-white/[.02]"}`}><Armchair className={`mx-auto mb-2 ${t.state==="Com pedidos"?"text-[#d7b778]":"text-[#68645d]"}`} size={17}/><div className="text-[11px] font-medium">{String(t.number).padStart(2,"0")}</div><div className="mt-1 text-[9px] text-[#77736b]">{t.state==="Com pedidos"?"Ocupada":"Livre"}</div></div>)}</div>
        <div className="mt-5 flex gap-4 text-[10px] text-[#858078]"><span className="flex items-center gap-1.5"><i className="h-2 w-2 rounded-full bg-[#c6a15b]"/>Com pedidos</span><span className="flex items-center gap-1.5"><i className="h-2 w-2 rounded-full bg-[#555]"/>Disponível</span></div>
      </div>
    </section>
  </AdminShell>;
}
