import { Sidebar } from "@/components/sidebar";
import { Bell, Search } from "lucide-react";
import { Logo } from "@/components/logo";

export function AdminShell({ children, title, subtitle }: { children: React.ReactNode; title: string; subtitle: string }) {
  return <div className="min-h-screen lg:flex">
    <Sidebar/>
    <main className="min-w-0 flex-1">
      <header className="sticky top-0 z-10 flex h-[76px] items-center justify-between border-b border-[var(--line)] bg-[#0b0b0c]/90 px-5 backdrop-blur-xl md:px-9">
        <div className="flex items-center gap-3 lg:hidden"><Logo size={40}/><div><div className="font-display text-gold text-sm font-bold tracking-[.14em]">LIDERANÇA</div><div className="text-[9px] tracking-[.25em] text-[#c6a15b]">LOUNGE BAR</div></div></div>
        <div className="hidden text-xs text-[#8d8981] lg:block">Painel administrativo <span className="px-2 text-[#c6a15b]">/</span> {title}</div>
        <div className="ml-auto flex items-center gap-3"><div className="hidden items-center gap-2 rounded-full border border-[var(--line)] px-3 py-2 text-xs text-[#8d8981] md:flex"><Search size={14}/> Buscar</div><button aria-label="Notificações" className="relative rounded-full border border-[var(--line)] p-2.5 text-[#c6a15b]"><Bell size={17}/><span className="absolute right-2 top-2 h-1.5 w-1.5 rounded-full bg-[#c6a15b]"/></button><Logo size={34}/></div>
      </header>
      <div className="mx-auto max-w-[1500px] px-5 py-8 md:px-9 md:py-10">
        <div className="mb-8"><div className="mb-2 text-[10px] font-semibold uppercase tracking-[.24em] text-[#c6a15b]">Liderança Lounge Bar</div><h1 className="font-display text-2xl font-semibold tracking-tight md:text-[32px]">{title}</h1><p className="mt-2 text-sm text-[#89867f]">{subtitle}</p></div>
        {children}
        <footer className="mt-12 border-t border-[var(--line)] pt-5 text-[10px] tracking-wide text-[#66635e]">LIDERANÇA LOUNGE BAR · SISTEMA DE GESTÃO · VERSÃO INICIAL</footer>
      </div>
    </main>
  </div>;
}
