/* eslint-disable @next/next/no-img-element */
export function Logo({ size = 44, className = "" }: { size?: number; className?: string }) {
  return <img src="/logo-512.png" alt="Liderança Lounge Bar" width={size} height={size}
    className={`rounded-full ring-1 ring-[#c6a15b]/50 shadow-[0_0_22px_rgba(198,161,91,.28)] ${className}`} />;
}
