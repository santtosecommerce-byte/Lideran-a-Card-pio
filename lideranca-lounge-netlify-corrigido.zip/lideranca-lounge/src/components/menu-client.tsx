"use client";
/* eslint-disable @next/next/no-img-element */
import { useEffect, useMemo, useState } from "react";
import { Wine, GlassWater, Beer, Droplets, Snowflake, Zap, Candy, Popcorn, Cigarette, Flame, Package, ShoppingBag, Minus, Plus, BellRing, Check } from "lucide-react";
import type { Category, Product } from "@/lib/catalog";

const ICONS: Record<string, React.ElementType> = { Wine, GlassWater, Beer, Droplets, Snowflake, Zap, Candy, Popcorn, Cigarette, Flame, Package, ShoppingBag };
const R = (cents: number) => (cents / 100).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
const STEPS = ["Recebido", "Pagamento confirmado", "Em preparo", "Pronto", "Entregue"];
const STEP_OF: Record<string, number> = { awaiting_payment: 0, new: 1, preparing: 2, ready: 3, delivered: 4 };
const FINAL = ["delivered", "cancelled"];

type Tracked = { id: string; number: number; status: string; updatedAt: string };
type Props = { table: { number: number; name: string; token: string }; categories: Category[] };

// Pequena animação: uma bolinha dourada voa do botão "+" até a barra do pedido.
function flyToCart(from: HTMLElement) {
  const a = from.getBoundingClientRect();
  const target = document.getElementById("cart-bar");
  const b = target?.getBoundingClientRect();
  const x2 = b ? b.left + b.width / 2 : window.innerWidth / 2;
  const y2 = b ? b.top + b.height / 2 : window.innerHeight - 40;
  const x1 = a.left + a.width / 2;
  const y1 = a.top + a.height / 2;
  const dot = document.createElement("div");
  dot.style.cssText = "position:fixed;left:0;top:0;width:14px;height:14px;margin:-7px 0 0 -7px;border-radius:50%;background:radial-gradient(circle,#f8e7b8,#b98d43);box-shadow:0 0 12px rgba(232,211,160,.8);z-index:60;pointer-events:none";
  document.body.appendChild(dot);
  dot.animate(
    [
      { transform: `translate(${x1}px,${y1}px) scale(1)`, opacity: 1 },
      { transform: `translate(${(x1 + x2) / 2}px,${Math.min(y1, y2) - 60}px) scale(1.1)`, opacity: 1, offset: 0.5 },
      { transform: `translate(${x2}px,${y2}px) scale(.3)`, opacity: 0.2 }
    ],
    { duration: 620, easing: "cubic-bezier(.4,0,.2,1)" }
  ).onfinish = () => dot.remove();
  navigator.vibrate?.(12);
}

export function MenuClient({ table, categories }: Props) {
  const [cart, setCart] = useState<Record<string, number>>({});
  const [adult, setAdult] = useState(false);
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [note, setNote] = useState("");
  const [sending, setSending] = useState(false);
  const [error, setError] = useState("");
  const [tab, setTab] = useState(0);
  const [tracked, setTracked] = useState<Tracked | null>(null);
  const [callOpen, setCallOpen] = useState(false);
  const [toast, setToast] = useState("");
  const storageKey = `ll-cart-${table.token}`;
  const orderKey = `ll-order-${table.token}`;

  const byId = useMemo(() => {
    const m: Record<string, Product> = {};
    categories.forEach(c => c.items.forEach(i => (m[i.id] = i)));
    return m;
  }, [categories]);

  // Carrega preferências salvas no aparelho.
  useEffect(() => {
    try {
      setAdult(sessionStorage.getItem("ll-18") === "1");
      setCart(JSON.parse(localStorage.getItem(storageKey) || "{}"));
      const id = localStorage.getItem(orderKey);
      if (id) setTracked({ id, number: 0, status: "awaiting_payment", updatedAt: "" });
    } catch { /* sem armazenamento */ }
  }, [storageKey, orderKey]);

  useEffect(() => {
    try { localStorage.setItem(storageKey, JSON.stringify(cart)); } catch { /* ignora */ }
  }, [cart, storageKey]);

  // Acompanha o status do pedido enquanto ele não estiver entregue ou cancelado.
  useEffect(() => {
    if (!tracked || FINAL.includes(tracked.status)) return;
    let alive = true;
    const poll = async () => {
      try {
        const res = await fetch(`/api/orders/${tracked.id}`, { cache: "no-store" });
        if (!res.ok) { if (res.status === 404) { try { localStorage.removeItem(orderKey); } catch { /* */ } setTracked(null); } return; }
        const { order } = await res.json();
        if (alive) setTracked(t => (t ? { ...t, number: order.number, status: order.status, updatedAt: order.updatedAt } : t));
      } catch { /* tenta de novo no próximo ciclo */ }
    };
    poll();
    const t = setInterval(poll, 5000);
    return () => { alive = false; clearInterval(t); };
  }, [tracked?.id, tracked?.status, orderKey]);

  // Destaca a aba da seção que está na tela.
  useEffect(() => {
    const els = categories.map((_, i) => document.getElementById(`c${i}`)).filter(Boolean) as HTMLElement[];
    const io = new IntersectionObserver(
      entries => entries.forEach(e => { if (e.isIntersecting) setTab(Number(e.target.id.slice(1))); }),
      { rootMargin: "-35% 0px -60% 0px" }
    );
    els.forEach(el => io.observe(el));
    return () => io.disconnect();
  }, [categories]);

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(""), 2600);
    return () => clearTimeout(t);
  }, [toast]);

  const lines = Object.entries(cart)
    .filter(([id, q]) => q > 0 && byId[id]?.available)
    .map(([id, q]) => ({ product: byId[id], quantity: q }));
  const count = lines.reduce((n, l) => n + l.quantity, 0);
  const total = lines.reduce((n, l) => n + l.product.priceCents * l.quantity, 0);

  function add(id: string, btn: HTMLElement) {
    flyToCart(btn);
    setCart(c => ({ ...c, [id]: Math.min(99, (c[id] ?? 0) + 1) }));
  }
  function remove(id: string) {
    setCart(c => {
      const q = (c[id] ?? 0) - 1;
      const next = { ...c, [id]: Math.max(0, q) };
      if (q <= 0) delete next[id];
      return next;
    });
  }

  async function send() {
    setSending(true);
    setError("");
    const res = await fetch("/api/orders", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        tableToken: table.token,
        items: lines.map(l => ({ productId: l.product.id, quantity: l.quantity })),
        customerName: name,
        note
      })
    });
    const data = await res.json().catch(() => ({}));
    setSending(false);
    if (!res.ok) {
      setError(data.error || "Não foi possível enviar o pedido. Tente de novo.");
      return;
    }
    try { localStorage.setItem(orderKey, data.order.id); } catch { /* */ }
    setTracked({ id: data.order.id, number: data.order.number, status: "awaiting_payment", updatedAt: "" });
    setCart({});
    setOpen(false);
    setNote("");
    setToast(`Pedido #${data.order.number} enviado`);
  }

  async function callStaff(reason: "garcom" | "conta") {
    setCallOpen(false);
    const res = await fetch("/api/calls", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ tableToken: table.token, reason })
    });
    setToast(res.ok
      ? (reason === "garcom" ? "Garçom avisado, já vamos até a mesa" : "Conta solicitada, já levamos")
      : "Não foi possível avisar agora. Tente de novo.");
  }

  const stepIndex = tracked ? (tracked.status === "cancelled" ? -1 : STEP_OF[tracked.status] ?? 0) : -1;

  return (
    <main className="min-h-screen pb-32">
      <header className="relative px-5 pt-8 text-center">
        <img src="/logo-512.png" alt="Liderança Lounge Bar" width={104} height={104} className="mx-auto rounded-full ring-1 ring-[#c6a15b]/50 shadow-[0_0_30px_rgba(198,161,91,.3)] transition-transform duration-700 hover:scale-[1.03]" />
        <h1 className="font-display text-gold mt-4 text-2xl font-medium tracking-[.2em]">LIDERANÇA</h1>
        <p className="mt-1 text-[9px] tracking-[.4em] text-[#c6a15b]">LOUNGE BAR</p>
        <p className="mt-4 inline-block rounded-full border border-[#e8d3a0]/25 px-4 py-2 text-xs text-[#c9c1b0]">Mesa {String(table.number).padStart(2, "0")}</p>
        <button aria-label="Chamar a equipe" onClick={() => setCallOpen(true)} className="absolute right-5 top-9 flex h-11 w-11 items-center justify-center rounded-full border border-[#e8d3a0]/30 text-[#e8d3a0] transition active:scale-95">
          <BellRing size={18} />
        </button>
      </header>

      {tracked && (
        <section className="mx-auto mt-6 max-w-xl px-4">
          <div className="rounded-2xl border border-[#e8d3a0]/25 bg-[#111113] p-4 shadow-[0_0_30px_-12px_rgba(198,161,91,.5)]">
            <div className="flex items-center justify-between">
              <span className="text-xs uppercase tracking-[.16em] text-[#c6a15b]">Seu pedido {tracked.number ? `#${tracked.number}` : ""}</span>
              {tracked.status === "cancelled" && <span className="text-[11px] text-red-300">Cancelado</span>}
            </div>
            {tracked.status === "cancelled" ? (
              <p className="mt-3 text-sm text-[#c9c1b0]">Este pedido foi cancelado. Fale com a equipe se precisar de ajuda.</p>
            ) : (
              <>
                <div className="mt-4 flex items-center">
                  {STEPS.map((s, i) => (
                    <div key={s} className="flex flex-1 items-center last:flex-none">
                      <div className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-[11px] transition-all duration-500 ${i <= stepIndex ? "bg-gradient-to-b from-[#f3dda4] to-[#b98d43] text-[#15120a]" : "border border-[#e8d3a0]/25 text-[#77736b]"} ${i === stepIndex ? "scale-110 shadow-[0_0_14px_rgba(232,211,160,.6)]" : ""}`}>
                        {i < stepIndex ? <Check size={13} /> : i + 1}
                      </div>
                      {i < STEPS.length - 1 && <div className={`mx-1 h-px flex-1 transition-colors duration-500 ${i < stepIndex ? "bg-[#c6a15b]" : "bg-[#e8d3a0]/15"}`} />}
                    </div>
                  ))}
                </div>
                <p className="mt-3 text-sm text-[#e8d3a0]">{STEPS[Math.max(0, stepIndex)]}{stepIndex === 4 ? " · bom apetite!" : ""}</p>
              </>
            )}
          </div>
        </section>
      )}

      <nav className="sticky top-0 z-10 mt-6 flex gap-2 overflow-x-auto border-b border-[#e8d3a0]/15 bg-[#070708]/90 px-4 py-3 backdrop-blur">
        {categories.map((c, i) => (
          <button key={c.name} onClick={() => { setTab(i); document.getElementById(`c${i}`)?.scrollIntoView({ behavior: "smooth" }); }}
            className={`shrink-0 rounded-full px-4 py-2 text-[11px] uppercase tracking-[.12em] transition-all duration-300 ${tab === i ? "scale-105 bg-gradient-to-b from-[#f3dda4] to-[#b98d43] font-bold text-[#15120a]" : "text-[#8f8a80]"}`}>
            {c.name}
          </button>
        ))}
      </nav>

      <div className="mx-auto max-w-xl px-4">
        {categories.map((c, ci) => (
          <section key={c.name} id={`c${ci}`} className="scroll-mt-20 pt-7">
            <h2 className="font-display text-gold text-2xl">{c.name}</h2>
            {c.description && <p className="mt-1 text-xs text-[#8f8a80]">{c.description}</p>}
            <div className="mt-3 space-y-3">
              {c.items.map(item => {
                const Icon = ICONS[item.icon] ?? ShoppingBag;
                const q = cart[item.id] ?? 0;
                return (
                  <div key={item.id} className={`flex items-center gap-3 rounded-2xl border border-[#e8d3a0]/15 bg-[#111113] p-3 transition-all duration-300 hover:border-[#e8d3a0]/30 active:scale-[.99] ${!item.available ? "opacity-50" : ""}`}>
                    <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border border-[#e8d3a0]/20 bg-[#c6a15b]/10 text-[#e8d3a0]"><Icon size={22} strokeWidth={1.5} /></span>
                    <div className="min-w-0 flex-1">
                      <div className={`text-[15px] ${!item.available ? "line-through text-[#8f8a80]" : ""}`}>{item.name}</div>
                      {item.description && <div className="mt-0.5 text-[11px] leading-snug text-[#8f8a80]">{item.description}</div>}
                      <div className="mt-1 text-sm font-semibold text-[#e8d3a0]">{R(item.priceCents)}</div>
                    </div>
                    {item.available ? (
                      <div className="flex shrink-0 items-center gap-2">
                        {q > 0 && <>
                          <button aria-label="Remover" onClick={() => remove(item.id)} className="flex h-8 w-8 items-center justify-center rounded-full border border-[#e8d3a0]/40 text-[#e8d3a0] transition active:scale-90"><Minus size={14} /></button>
                          <span className="w-5 text-center text-sm font-semibold">{q}</span>
                        </>}
                        <button aria-label="Adicionar" onClick={e => add(item.id, e.currentTarget)} className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-b from-[#f3dda4] to-[#b98d43] text-[#15120a] transition active:scale-90"><Plus size={14} /></button>
                      </div>
                    ) : <span className="shrink-0 text-[10px] text-[#8f8a80]">Indisponível</span>}
                  </div>
                );
              })}
            </div>
          </section>
        ))}
        <footer className="mt-14 pb-6 text-center text-[9px] tracking-[.38em] text-[#8a7650]">UMA EXPERIÊNCIA ALÉM DO COMUM</footer>
      </div>

      <div id="cart-bar" className={`fixed inset-x-0 bottom-0 z-20 bg-gradient-to-t from-[#070708] via-[#070708]/90 to-transparent px-4 pb-[calc(16px+env(safe-area-inset-bottom))] pt-6 transition-all duration-500 ${count > 0 && !open ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-6 opacity-0"}`}>
        <button onClick={() => setOpen(true)} className="mx-auto flex w-full max-w-xl items-center justify-between rounded-2xl bg-gradient-to-b from-[#f3dda4] to-[#b98d43] px-5 py-4 font-bold text-[#15120a] shadow-[0_14px_34px_-10px_rgba(198,161,91,.55)] transition active:scale-[.98]">
          <span className="flex items-center gap-2"><ShoppingBag size={18} /> Ver pedido · {count} {count > 1 ? "itens" : "item"}</span>
          <span>{R(total)}</span>
        </button>
      </div>

      {toast && (
        <div className="fixed inset-x-0 top-5 z-50 flex justify-center px-5">
          <div className="rounded-full border border-[#e8d3a0]/30 bg-[#121214]/95 px-5 py-3 text-sm text-[#e8d3a0] shadow-[0_10px_30px_rgba(0,0,0,.5)] animate-[fadeIn_.3s_ease-out]">{toast}</div>
        </div>
      )}

      {callOpen && (
        <div className="fixed inset-0 z-40 flex items-end justify-center bg-black/70" onClick={e => e.target === e.currentTarget && setCallOpen(false)}>
          <div className="w-full max-w-xl rounded-t-3xl border border-[#e8d3a0]/30 bg-[#121214] p-5 pb-[calc(20px+env(safe-area-inset-bottom))]">
            <h3 className="font-display text-gold text-xl">Chamar a equipe</h3>
            <button onClick={() => callStaff("garcom")} className="mt-4 w-full rounded-2xl border border-[#e8d3a0]/25 py-4 text-[#e8d3a0] transition active:scale-[.98]">Chamar o garçom</button>
            <button onClick={() => callStaff("conta")} className="mt-3 w-full rounded-2xl border border-[#e8d3a0]/25 py-4 text-[#e8d3a0] transition active:scale-[.98]">Pedir a conta</button>
          </div>
        </div>
      )}

      {open && (
        <div className="fixed inset-0 z-30 flex items-end justify-center bg-black/70" onClick={e => e.target === e.currentTarget && setOpen(false)}>
          <div className="max-h-[90vh] w-full max-w-xl overflow-auto rounded-t-3xl border border-[#e8d3a0]/30 bg-[#121214] p-5 pb-[calc(20px+env(safe-area-inset-bottom))]">
            <h3 className="font-display text-gold text-2xl">Seu pedido</h3>
            <div className="mt-3 divide-y divide-[#e8d3a0]/15">
              {lines.map(l => (
                <div key={l.product.id} className="flex items-center justify-between py-2 text-sm">
                  <span>{l.quantity}× {l.product.name}</span>
                  <span className="flex items-center gap-3"><span className="text-[#e8d3a0]">{R(l.product.priceCents * l.quantity)}</span></span>
                </div>
              ))}
            </div>
            <div className="mt-4 space-y-3">
              <input value={name} onChange={e => setName(e.target.value)} maxLength={40} placeholder="Seu nome (opcional)" className="w-full rounded-xl border border-[#e8d3a0]/15 bg-[#17171a] px-4 py-3 text-base outline-none" />
              <textarea value={note} onChange={e => setNote(e.target.value)} maxLength={200} rows={2} placeholder="Observação (ex.: sem gelo)" className="w-full rounded-xl border border-[#e8d3a0]/15 bg-[#17171a] px-4 py-3 text-base outline-none" />
            </div>
            <div className="mt-5 flex items-baseline justify-between">
              <span className="text-xs uppercase tracking-[.14em] text-[#8f8a80]">Total</span>
              <span className="font-display text-2xl text-[#e8d3a0]">{R(total)}</span>
            </div>
            <p className="mt-2 text-[11px] leading-relaxed text-[#8f8a80]">O pagamento é feito no caixa. Depois de pagar, a equipe confirma e prepara o seu pedido.</p>
            {error && <p className="mt-3 rounded-xl border border-red-400/30 bg-red-400/10 p-3 text-xs text-red-200">{error}</p>}
            <button disabled={sending || lines.length === 0} onClick={send} className="mt-5 w-full rounded-2xl bg-gradient-to-b from-[#f3dda4] to-[#b98d43] py-4 font-bold uppercase tracking-[.06em] text-[#15120a] transition active:scale-[.98] disabled:opacity-50">
              {sending ? "Enviando…" : "Enviar pedido"}
            </button>
            <button onClick={() => setOpen(false)} className="mt-3 w-full rounded-2xl border border-[#e8d3a0]/30 py-3 text-[#e8d3a0]">Continuar escolhendo</button>
          </div>
        </div>
      )}

      {!adult && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-5">
          <div className="w-full max-w-sm rounded-3xl border border-[#e8d3a0]/30 bg-[#121214] p-6 text-center">
            <h3 className="font-display text-gold text-2xl">Maiores de 18 anos</h3>
            <p className="mt-3 text-sm leading-relaxed text-[#c9c1b0]">Este cardápio tem bebidas alcoólicas e cigarros. Você confirma que tem 18 anos ou mais?</p>
            <button onClick={() => { try { sessionStorage.setItem("ll-18", "1"); } catch { /* */ } setAdult(true); }} className="mt-5 w-full rounded-2xl bg-gradient-to-b from-[#f3dda4] to-[#b98d43] py-3 font-bold text-[#15120a]">Sim, tenho 18 anos ou mais</button>
            <p className="mt-4 text-xs text-[#8f8a80]">Este cardápio é destinado a maiores de 18 anos.</p>
          </div>
        </div>
      )}
    </main>
  );
}
