import Link from "next/link";
import { Logo } from "@/components/logo";
import { LayoutDashboard, ClipboardList, UtensilsCrossed, Armchair, Settings, LogOut } from "lucide-react";

const links = [
  { href: "/", label: "Visão geral", icon: LayoutDashboard },
  { href: "/admin/orders", label: "Pedidos", icon: ClipboardList },
  { href: "/admin/products", label: "Cardápio", icon: UtensilsCrossed },
  { href: "/admin/tables", label: "Mesas e QR Codes", icon: Armchair }
];

export function Sidebar() {
  return <aside className="hidden lg:flex w-[250px] shrink-0 flex-col border-r border-[var(--line)] bg-[#101011] px-5 py-7">
    <div className="mb-12 flex items-center gap-3 px-2">
      <Logo size={48}/>
      <div><div className="font-display text-gold text-[16px] font-bold tracking-[.14em]">LIDERANÇA</div><div className="mt-1 text-[9px] tracking-[.28em] text-[#c6a15b]">LOUNGE BAR</div></div>
    </div>
    <div className="mb-3 px-3 text-[10px] font-semibold uppercase tracking-[.2em] text-[#77736b]">Operação</div>
    <nav className="space-y-1">
      {links.map(({ href, label, icon: Icon }, i) => <Link key={href} href={href} className={`flex items-center gap-3 rounded-xl px-3 py-3 text-sm transition ${i === 0 && href === "/" ? "bg-[#c6a15b]/10 text-[#e0c58c]" : "text-[#aaa69e] hover:bg-white/[.04] hover:text-white"}`}><Icon size={17}/>{label}</Link>)}
    </nav>
    <div className="mt-auto border-t border-[var(--line)] pt-5">
      <div className="flex items-center gap-3 rounded-xl bg-white/[.03] p-3"><div className="flex h-9 w-9 items-center justify-center rounded-full bg-[#c6a15b]/15 text-sm text-[#e0c58c]">LB</div><div className="min-w-0"><div className="text-xs font-medium">Administrador</div><div className="text-[10px] text-[#77736b]">Acesso local demonstrativo</div></div></div>
      <div className="mt-4 flex items-center gap-3 px-3 text-xs text-[#77736b]"><Settings size={15}/> Configurações <a href="/api/staff/logout" aria-label="Sair" className="ml-auto text-[#c6a15b]"><LogOut size={15}/></a></div>
    </div>
  </aside>;
}
