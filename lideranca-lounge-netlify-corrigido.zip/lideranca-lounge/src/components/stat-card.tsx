export function StatCard({ label, value, note, icon: Icon }: { label: string; value: string; note: string; icon: React.ElementType }) {
  return <div className="rounded-2xl border border-[var(--line)] bg-[linear-gradient(145deg,#19191b,#111112)] p-5">
    <div className="flex items-start justify-between"><span className="text-xs text-[#99958d]">{label}</span><span className="rounded-xl bg-[#c6a15b]/10 p-2 text-[#c6a15b]"><Icon size={17}/></span></div>
    <div className="mt-5 text-[27px] font-semibold tracking-tight">{value}</div><div className="mt-1 text-[11px] text-[#77736b]">{note}</div>
  </div>;
}
