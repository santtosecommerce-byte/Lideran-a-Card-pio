import { findTableByToken } from "./tables";

// Chamados da mesa (garçom / conta). Mesmo aviso: memória do servidor, veja README.
export type CallReason = "garcom" | "conta";
export type Call = { id: string; tableNumber: number; tableName: string; reason: CallReason; createdAt: string; resolved: boolean };

const g = globalThis as typeof globalThis & { __llCalls?: Call[] };
function calls(): Call[] {
  if (!g.__llCalls) g.__llCalls = [];
  return g.__llCalls;
}

export function openCalls(): Call[] {
  return calls().filter(c => !c.resolved).sort((a, b) => a.createdAt.localeCompare(b.createdAt));
}

export function createCall(tableToken: string, reason: string): { ok: true; value: Call } | { ok: false; error: string } {
  const table = findTableByToken(String(tableToken ?? ""));
  if (!table) return { ok: false, error: "Mesa não encontrada ou inativa." };
  if (reason !== "garcom" && reason !== "conta") return { ok: false, error: "Motivo inválido." };
  // Evita repetir o mesmo chamado enquanto o anterior não foi atendido.
  const existing = openCalls().find(c => c.tableNumber === table.number && c.reason === reason);
  if (existing) return { ok: true, value: existing };
  const call: Call = {
    id: crypto.randomUUID(),
    tableNumber: table.number,
    tableName: table.name,
    reason,
    createdAt: new Date().toISOString(),
    resolved: false
  };
  calls().push(call);
  return { ok: true, value: call };
}

export function resolveCall(id: string): boolean {
  const c = calls().find(x => x.id === id);
  if (!c) return false;
  c.resolved = true;
  return true;
}
