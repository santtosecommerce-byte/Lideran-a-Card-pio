import { menu } from "./menu-data";

// Catálogo com ids estáveis. O servidor usa estes preços; o navegador nunca define preço.
export type Product = {
  id: string;
  name: string;
  description?: string;
  category: string;
  priceCents: number;
  available: boolean;
  icon: string;
};
export type Category = { name: string; description: string; items: Product[] };

const ITEM_DESC: Record<string, string> = {
  "Batata simples": "Batata, ketchup, maionese e queijo ralado",
  "Batata com nugget": "Batata, nugget, cheddar e molho especial",
  "Batata turbinada": "Batata, molho cheddar, ketchup, maionese e bacon",
  "Burguer salada": "Pão gergelim, alface, tomate, carne, cheddar, fatia de queijo cheddar e molho especial",
  "Líder burguer": "Pão de brioche, carne, cheddar, fatia de queijo e molho especial",
  "Líder cheddar": "Pão de brioche, carne, cheddar, fatia de queijo e molho"
};

const slug = (s: string) =>
  s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");

function iconFor(cat: string, n: string): string {
  const l = n.toLowerCase();
  if (cat.startsWith("Combos Whisky")) return "Wine";
  if (cat.startsWith("Combos Gin") || cat.startsWith("Dose")) return "GlassWater";
  if (cat.startsWith("Bebidas")) return l.includes("smirnoff") ? "GlassWater" : "Beer";
  if (cat.startsWith("Diversos")) {
    if (l === "água") return "Droplets";
    if (l.includes("gelo")) return "Snowflake";
    if (l.includes("red bull")) return "Zap";
    if (["coca", "guaran", "del valle"].some(k => l.includes(k))) return "GlassWater";
    if (["fofura", "torcida"].some(k => l.includes(k))) return "Popcorn";
    return "Candy";
  }
  if (cat.startsWith("Cigarros")) {
    if (l.includes("isqueiro") || l.includes("bic")) return "Flame";
    if (l.includes("seda") || l.includes("piteira")) return "Package";
    return "Cigarette";
  }
  if (cat.startsWith("Narguil")) return "Flame";
  return "ShoppingBag";
}

export const categories: Category[] = menu.map(c => ({
  name: c.name,
  description: c.description,
  items: c.items.map(i => ({
    id: slug(`${c.name}-${i.name}`),
    name: i.name,
    description: ITEM_DESC[i.name],
    category: c.name,
    priceCents: i.priceCents,
    available: i.available,
    icon: iconFor(c.name, i.name)
  }))
}));

export const products: Product[] = categories.flatMap(c => c.items);

export function productById(id: string): Product | null {
  return products.find(p => p.id === id) ?? null;
}
