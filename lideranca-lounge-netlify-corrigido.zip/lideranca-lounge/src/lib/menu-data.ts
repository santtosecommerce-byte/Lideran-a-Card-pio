export type MenuItem = { name: string; priceCents: number; available: boolean };
export type MenuCategory = { name: string; description: string; items: MenuItem[] };

export const menu: MenuCategory[] = [
  { name: "Combos Whisky", description: "Garrafa para a mesa", items: [
    { name: "Gold Label", priceCents: 50000, available: true },
    { name: "Buchanan's", priceCents: 40000, available: true },
    { name: "Black Label", priceCents: 39000, available: true },
    { name: "Jack Daniel's", priceCents: 37000, available: true },
    { name: "Old Parr", priceCents: 35000, available: true },
    { name: "Red Label", priceCents: 30000, available: true },
    { name: "Ballantine's", priceCents: 26000, available: true },
    { name: "White Horse", priceCents: 26000, available: true }
  ] },
  { name: "Combos Gin & Vodka", description: "Garrafa para a mesa", items: [
    { name: "Gin Beefeater", priceCents: 30000, available: true },
    { name: "Gin Tanqueray", priceCents: 35000, available: true },
    { name: "Vodka Ciroc", priceCents: 40000, available: true },
    { name: "Vodka Grey Goose", priceCents: 37000, available: true },
    { name: "Vodka Absolut", priceCents: 28000, available: true }
  ] },
  { name: "Dose Whisky", description: "Dose individual", items: [
    { name: "Black Label", priceCents: 7000, available: true },
    { name: "Jack Daniel's", priceCents: 6000, available: true },
    { name: "Red Label", priceCents: 5000, available: true },
    { name: "Ballantine's", priceCents: 4500, available: true },
    { name: "White Horse", priceCents: 4500, available: true },
    { name: "Old Parr", priceCents: 6000, available: true }
  ] },
  { name: "Dose Gin & Vodka", description: "Dose individual", items: [
    { name: "Gin Beefeater", priceCents: 5000, available: true },
    { name: "Gin Tanqueray", priceCents: 6000, available: true },
    { name: "Gin Eternety", priceCents: 2000, available: true },
    { name: "Vodka Ciroc", priceCents: 7000, available: true },
    { name: "Vodka Absolut", priceCents: 4500, available: true }
  ] },
  { name: "Bebidas Alcoólicas", description: "", items: [
    { name: "Heineken", priceCents: 1000, available: true },
    { name: "Corona", priceCents: 1200, available: true },
    { name: "Skol Beats", priceCents: 1000, available: true },
    { name: "Smirnoff Ice", priceCents: 1000, available: true }
  ] },
  { name: "Diversos", description: "", items: [
    { name: "Água", priceCents: 500, available: true },
    { name: "Gelo de coco", priceCents: 500, available: true },
    { name: "Gelo de água", priceCents: 300, available: true },
    { name: "Red Bull", priceCents: 1500, available: true },
    { name: "Coca-Cola", priceCents: 700, available: true },
    { name: "Guaraná", priceCents: 700, available: true },
    { name: "Del Valle", priceCents: 800, available: true },
    { name: "Trident", priceCents: 500, available: true },
    { name: "Halls", priceCents: 500, available: true },
    { name: "Mentos", priceCents: 500, available: true },
    { name: "Trento", priceCents: 800, available: true },
    { name: "Fofura", priceCents: 500, available: true },
    { name: "Torcida", priceCents: 500, available: true }
  ] },
  { name: "Cigarros", description: "Venda somente para maiores de 18 anos", items: [
    { name: "Rothmans", priceCents: 1200, available: true },
    { name: "Carlton", priceCents: 2000, available: true },
    { name: "Marlboro", priceCents: 2000, available: true },
    { name: "Gudang", priceCents: 350, available: true },
    { name: "Seda longa", priceCents: 1000, available: true },
    { name: "Seda pequena", priceCents: 800, available: true },
    { name: "Piteira", priceCents: 600, available: true },
    { name: "Bic", priceCents: 1000, available: true },
    { name: "Isqueiro", priceCents: 700, available: true },
    { name: "Rothmans (solto)", priceCents: 100, available: true },
    { name: "Carlton (solto)", priceCents: 200, available: true },
    { name: "Marlboro (solto)", priceCents: 200, available: true },
    { name: "Gudang (3 por R$ 10)", priceCents: 1000, available: true },
    { name: "Seda longa (solta)", priceCents: 100, available: true },
    { name: "Seda pequena (solta)", priceCents: 50, available: true },
    { name: "Piteira (solta)", priceCents: 50, available: true }
  ] },
  { name: "Narguilé", description: "Consultar o sabor das essências no balcão", items: [
    { name: "Aluguel de narguilé", priceCents: 3000, available: true },
    { name: "Troca de rosh", priceCents: 2000, available: true }
  ] },
  { name: "Porções", description: "", items: [
    { name: "Batata simples", priceCents: 1600, available: true },
    { name: "Batata com nugget", priceCents: 3500, available: true },
    { name: "Batata turbinada", priceCents: 2500, available: true },
    { name: "Batata calabresa", priceCents: 3500, available: false },
    { name: "Nugget", priceCents: 3500, available: true },
    { name: "Frango a passarinho", priceCents: 4000, available: false },
    { name: "Calabresa", priceCents: 4000, available: false }
  ] },
  { name: "Lanches", description: "", items: [
    { name: "Burguer salada", priceCents: 2000, available: false },
    { name: "Líder burguer", priceCents: 1600, available: true },
    { name: "Líder cheddar", priceCents: 2100, available: true }
  ] },
];
