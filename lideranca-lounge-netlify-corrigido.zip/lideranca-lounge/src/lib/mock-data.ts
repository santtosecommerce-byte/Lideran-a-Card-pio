export type OrderStatus = "Novo" | "Em preparo" | "Pronto" | "Entregue";
export type Order = {
  id: string; table: string; time: string; status: OrderStatus;
  items: { name: string; quantity: number; note?: string }[];
  total: number; payment: "Pago" | "Pendente";
};

export const orders: Order[] = [
  { id: "1024", table: "Mesa 04", time: "21:42", status: "Novo", items: [{ name: "Gin tônica", quantity: 2 }, { name: "Batata rústica", quantity: 1, note: "Sem molho" }], total: 78, payment: "Pago" },
  { id: "1023", table: "Mesa 07", time: "21:38", status: "Em preparo", items: [{ name: "Lanche da casa", quantity: 1 }, { name: "Refrigerante", quantity: 2 }], total: 64, payment: "Pago" },
  { id: "1022", table: "Mesa 02", time: "21:31", status: "Pronto", items: [{ name: "Porção de calabresa", quantity: 1 }], total: 52, payment: "Pago" },
  { id: "1021", table: "Mesa 11", time: "21:18", status: "Entregue", items: [{ name: "Água sem gás", quantity: 2 }], total: 12, payment: "Pago" }
];

export const tables = Array.from({ length: 15 }, (_, i) => ({
  number: i + 1,
  name: `Mesa ${String(i + 1).padStart(2, "0")}`,
  token: `M${String(i + 1).padStart(2, "0")}-demo-token`,
  state: [2, 4, 7, 11].includes(i + 1) ? "Com pedidos" : "Disponível"
}));
