import { productById } from "./catalog";
import { findTableByToken } from "./tables";

// ATENÇÃO: este armazenamento fica na memória do servidor. Em desenvolvimento funciona,
// mas na Netlify cada função pode ter a sua memória e os pedidos se perdem.
// Antes de publicar, troque por tabelas `orders` e `order_items` do Supabase.
export type OrderStatus = "awaiting_payment" | "new" | "preparing" | "ready" | "delivered" | "cancelled";
export type OrderItem = { productId: string; name: string; quantity: number; unitPriceCents: number; lineTotalCents: number };
export type Order = {
  id: string;
  number: number;
  tableNumber: number;
  tableName: string;
  customerName: string;
  note: string;
  items: OrderItem[];
  totalCents: number;
  status: OrderStatus;
  paymentStatus: "pending" | "approved";
  createdAt: string;
  updatedAt: string;
};
export type OrderAction = "confirm_payment" | "prepare" | "ready" | "deliver" | "cancel";
export type Result<T> = { ok: true; value: T } | { ok: false; error: string };

type Store = { orders: Order[]; seq: number };
const g = globalThis as typeof globalThis & { __llStore?: Store };
function store(): Store {
  if (!g.__llStore) g.__llStore = { orders: [], seq: 1000 };
  return g.__llStore;
}

export function listOrders(): Order[] {
  return [...store().orders].sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 200);
}

export type CreateInput = { tableToken: string; items: { productId: string; quantity: number }[]; customerName?: string; note?: string };

export function createOrder(input: CreateInput): Result<Order> {
  const table = findTableByToken(String(input.tableToken ?? ""));
  if (!table) return { ok: false, error: "Mesa não encontrada ou inativa." };
  if (!Array.isArray(input.items) || input.items.length === 0 || input.items.length > 30) {
    return { ok: false, error: "Escolha pelo menos um item." };
  }

  const merged = new Map<string, number>();
  for (const it of input.items) {
    const q = Number(it.quantity);
    if (!Number.isInteger(q) || q < 1 || q > 99) return { ok: false, error: "Quantidade inválida." };
    const id = String(it.productId);
    merged.set(id, (merged.get(id) ?? 0) + q);
  }

  const items: OrderItem[] = [];
  for (const [productId, quantity] of merged) {
    const p = productById(productId);
    if (!p) return { ok: false, error: "Um item do pedido não existe mais." };
    if (!p.available) return { ok: false, error: `${p.name} está indisponível.` };
    if (quantity > 99) return { ok: false, error: `Quantidade máxima de ${p.name} é 99.` };
    items.push({ productId, name: p.name, quantity, unitPriceCents: p.priceCents, lineTotalCents: p.priceCents * quantity });
  }

  const now = new Date().toISOString();
  const s = store();
  s.seq += 1;
  const order: Order = {
    id: crypto.randomUUID(),
    number: s.seq,
    tableNumber: table.number,
    tableName: table.name,
    customerName: String(input.customerName ?? "").trim().slice(0, 40),
    note: String(input.note ?? "").trim().slice(0, 200),
    items,
    totalCents: items.reduce((n, i) => n + i.lineTotalCents, 0),
    status: "awaiting_payment",
    paymentStatus: "pending",
    createdAt: now,
    updatedAt: now
  };
  s.orders.push(order);
  return { ok: true, value: order };
}

const RULES: Record<OrderAction, { from: OrderStatus[]; to: OrderStatus }> = {
  confirm_payment: { from: ["awaiting_payment"], to: "new" },
  prepare: { from: ["new"], to: "preparing" },
  ready: { from: ["preparing"], to: "ready" },
  deliver: { from: ["ready"], to: "delivered" },
  cancel: { from: ["awaiting_payment", "new", "preparing", "ready"], to: "cancelled" }
};

export function applyAction(id: string, action: OrderAction): Result<Order> {
  const rule = RULES[action];
  if (!rule) return { ok: false, error: "Ação inválida." };
  const order = store().orders.find(o => o.id === id);
  if (!order) return { ok: false, error: "Pedido não encontrado." };
  if (!rule.from.includes(order.status)) return { ok: false, error: "Essa ação não é possível neste status." };
  order.status = rule.to;
  if (action === "confirm_payment") order.paymentStatus = "approved";
  order.updatedAt = new Date().toISOString();
  return { ok: true, value: order };
}

// Visão pública (cliente): só o necessário para acompanhar o status.
export function getOrderPublic(id: string) {
  const o = store().orders.find(x => x.id === id);
  if (!o) return null;
  return { number: o.number, status: o.status, paymentStatus: o.paymentStatus, tableName: o.tableName, totalCents: o.totalCents, updatedAt: o.updatedAt };
}
