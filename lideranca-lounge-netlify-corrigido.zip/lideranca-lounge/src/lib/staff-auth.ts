// Acesso da equipe. Interino: senha única (STAFF_PASSWORD) + cookie assinado (STAFF_SECRET).
// Substituir por Supabase Auth (e-mail e senha, com cargos) no próximo passo.
export const STAFF_COOKIE = "ll_staff";
const enc = new TextEncoder();

async function hmacHex(data: string): Promise<string> {
  const secret = process.env.STAFF_SECRET;
  if (!secret) throw new Error("STAFF_SECRET não configurado");
  const key = await crypto.subtle.importKey("raw", enc.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const sig = await crypto.subtle.sign("HMAC", key, enc.encode(data));
  return Array.from(new Uint8Array(sig)).map(b => b.toString(16).padStart(2, "0")).join("");
}

export async function makeSessionToken(): Promise<string> {
  return "staff." + (await hmacHex("staff-session-v1"));
}

export function safeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

export async function isValidSession(token: string | undefined): Promise<boolean> {
  if (!token || !process.env.STAFF_SECRET) return false;
  return safeEqual(token, await makeSessionToken());
}
