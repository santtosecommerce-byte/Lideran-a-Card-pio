// Mesas do estabelecimento. Ficam na memória do servidor, como os pedidos (veja README).
// Ao ligar o Supabase, troque o store por consultas à tabela `tables`.
export type TableInfo = { number: number; name: string; token: string; active: boolean };

const MAX_TABLES = 300;
const MAX_PER_REQUEST = 100;

export const pad = (n: number) => String(n).padStart(2, "0");
export const nameFor = (n: number) => `Mesa ${pad(n)}`;

type Store = { tables: TableInfo[] };
const g = globalThis as typeof globalThis & { __llTables?: Store };

function store(): Store {
  if (!g.__llTables) {
    // Mesas iniciais com tokens de demonstração. Troque por tokens aleatórios antes de imprimir.
    g.__llTables = {
      tables: Array.from({ length: 15 }, (_, i) => ({
        number: i + 1,
        name: nameFor(i + 1),
        token: `M${pad(i + 1)}-demo-token`,
        active: true
      }))
    };
  }
  return g.__llTables;
}

function newToken(): string {
  // Token longo e imprevisível para o QR Code.
  return crypto.randomUUID().replace(/-/g, "").slice(0, 20);
}

export function listTables(): TableInfo[] {
  return [...store().tables].sort((a, b) => a.number - b.number);
}

export function findTableByToken(token: string): TableInfo | null {
  return store().tables.find(t => t.token === token && t.active) ?? null;
}

export function addTables(count: unknown): { ok: true; added: number } | { ok: false; error: string } {
  const n = Number(count);
  if (!Number.isInteger(n) || n < 1 || n > MAX_PER_REQUEST) {
    return { ok: false, error: `Informe entre 1 e ${MAX_PER_REQUEST} mesas por vez.` };
  }
  const s = store();
  if (s.tables.length + n > MAX_TABLES) {
    return { ok: false, error: `O limite total é de ${MAX_TABLES} mesas.` };
  }
  const start = Math.max(0, ...s.tables.map(t => t.number)) + 1;
  for (let i = 0; i < n; i++) {
    const number = start + i;
    s.tables.push({ number, name: nameFor(number), token: newToken(), active: true });
  }
  return { ok: true, added: n };
}

export function setTableActive(number: number, active: boolean): boolean {
  const t = store().tables.find(x => x.number === number);
  if (!t) return false;
  t.active = active;
  return true;
}
