import { NextRequest, NextResponse } from "next/server";
import { STAFF_COOKIE, isValidSession } from "@/lib/staff-auth";

// Rotas públicas para o cliente: criar pedido, acompanhar pedido e chamar a equipe.
function isPublicApi(req: NextRequest): boolean {
  const p = req.nextUrl.pathname;
  if (p === "/api/orders" && req.method === "POST") return true;
  if (p === "/api/calls" && req.method === "POST") return true;
  if (/^\/api\/orders\/[^/]+$/.test(p) && req.method === "GET") return true;
  return false;
}

export async function middleware(req: NextRequest) {
  if (isPublicApi(req)) return NextResponse.next();

  const ok = await isValidSession(req.cookies.get(STAFF_COOKIE)?.value);
  if (ok) return NextResponse.next();

  if (req.nextUrl.pathname.startsWith("/api/")) {
    return NextResponse.json({ error: "Acesso restrito à equipe." }, { status: 401 });
  }
  const url = req.nextUrl.clone();
  url.pathname = "/login";
  url.search = "";
  return NextResponse.redirect(url);
}

export const config = {
  matcher: ["/", "/admin/:path*", "/api/orders", "/api/orders/:path*", "/api/calls", "/api/calls/:path*", "/api/tables", "/api/tables/:path*"]
};
