-- Permite cadastrar quantas mesas o estabelecimento precisar (antes o limite era 15).
alter table public.tables drop constraint if exists tables_number_check;
alter table public.tables add constraint tables_number_check check (number >= 1);
