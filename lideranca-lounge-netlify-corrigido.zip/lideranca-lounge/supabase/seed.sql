-- 15 mesas de demonstração. Troque os tokens por valores aleatórios antes de produção.
insert into public.tables (number, name, qr_token)
values
(1, 'Mesa 01', 'M01-demo-token'),
(2, 'Mesa 02', 'M02-demo-token'),
(3, 'Mesa 03', 'M03-demo-token'),
(4, 'Mesa 04', 'M04-demo-token'),
(5, 'Mesa 05', 'M05-demo-token'),
(6, 'Mesa 06', 'M06-demo-token'),
(7, 'Mesa 07', 'M07-demo-token'),
(8, 'Mesa 08', 'M08-demo-token'),
(9, 'Mesa 09', 'M09-demo-token'),
(10, 'Mesa 10', 'M10-demo-token'),
(11, 'Mesa 11', 'M11-demo-token'),
(12, 'Mesa 12', 'M12-demo-token'),
(13, 'Mesa 13', 'M13-demo-token'),
(14, 'Mesa 14', 'M14-demo-token'),
(15, 'Mesa 15', 'M15-demo-token')
on conflict (number) do update
set name = excluded.name, qr_token = excluded.qr_token;
