-- Cardápio real do Liderança Lounge Bar (transcrito do cardápio impresso).
-- Pode rodar mais de uma vez: não duplica categorias nem produtos.

insert into public.categories (name, description, sort_order)
select 'Combos Whisky', 'Garrafa para a mesa', 1
where not exists (select 1 from public.categories where name = 'Combos Whisky');

insert into public.products (category_id, name, price_cents, sort_order)
select c.id, v.name, v.price_cents, v.sort_order
from public.categories c
join (values
  ('Gold Label', 50000, 1),
  ('Buchanan''s', 40000, 2),
  ('Black Label', 39000, 3),
  ('Jack Daniel''s', 37000, 4),
  ('Old Parr', 35000, 5),
  ('Red Label', 30000, 6),
  ('Ballantine''s', 26000, 7),
  ('White Horse', 26000, 8)
) as v(name, price_cents, sort_order) on true
where c.name = 'Combos Whisky'
and not exists (select 1 from public.products x where x.category_id = c.id and x.name = v.name);

insert into public.categories (name, description, sort_order)
select 'Combos Gin & Vodka', 'Garrafa para a mesa', 2
where not exists (select 1 from public.categories where name = 'Combos Gin & Vodka');

insert into public.products (category_id, name, price_cents, sort_order)
select c.id, v.name, v.price_cents, v.sort_order
from public.categories c
join (values
  ('Gin Beefeater', 30000, 1),
  ('Gin Tanqueray', 35000, 2),
  ('Vodka Ciroc', 40000, 3),
  ('Vodka Grey Goose', 37000, 4),
  ('Vodka Absolut', 28000, 5)
) as v(name, price_cents, sort_order) on true
where c.name = 'Combos Gin & Vodka'
and not exists (select 1 from public.products x where x.category_id = c.id and x.name = v.name);

insert into public.categories (name, description, sort_order)
select 'Dose Whisky', 'Dose individual', 3
where not exists (select 1 from public.categories where name = 'Dose Whisky');

insert into public.products (category_id, name, price_cents, sort_order)
select c.id, v.name, v.price_cents, v.sort_order
from public.categories c
join (values
  ('Black Label', 7000, 1),
  ('Jack Daniel''s', 6000, 2),
  ('Red Label', 5000, 3),
  ('Ballantine''s', 4500, 4),
  ('White Horse', 4500, 5),
  ('Old Parr', 6000, 6)
) as v(name, price_cents, sort_order) on true
where c.name = 'Dose Whisky'
and not exists (select 1 from public.products x where x.category_id = c.id and x.name = v.name);

insert into public.categories (name, description, sort_order)
select 'Dose Gin & Vodka', 'Dose individual', 4
where not exists (select 1 from public.categories where name = 'Dose Gin & Vodka');

insert into public.products (category_id, name, price_cents, sort_order)
select c.id, v.name, v.price_cents, v.sort_order
from public.categories c
join (values
  ('Gin Beefeater', 5000, 1),
  ('Gin Tanqueray', 6000, 2),
  ('Gin Eternety', 2000, 3),
  ('Vodka Ciroc', 7000, 4),
  ('Vodka Absolut', 4500, 5)
) as v(name, price_cents, sort_order) on true
where c.name = 'Dose Gin & Vodka'
and not exists (select 1 from public.products x where x.category_id = c.id and x.name = v.name);

insert into public.categories (name, description, sort_order)
select 'Bebidas Alcoólicas', null, 5
where not exists (select 1 from public.categories where name = 'Bebidas Alcoólicas');

insert into public.products (category_id, name, price_cents, sort_order)
select c.id, v.name, v.price_cents, v.sort_order
from public.categories c
join (values
  ('Heineken', 1000, 1),
  ('Corona', 1200, 2),
  ('Skol Beats', 1000, 3),
  ('Smirnoff Ice', 1000, 4)
) as v(name, price_cents, sort_order) on true
where c.name = 'Bebidas Alcoólicas'
and not exists (select 1 from public.products x where x.category_id = c.id and x.name = v.name);

insert into public.categories (name, description, sort_order)
select 'Diversos', null, 6
where not exists (select 1 from public.categories where name = 'Diversos');

insert into public.products (category_id, name, price_cents, sort_order)
select c.id, v.name, v.price_cents, v.sort_order
from public.categories c
join (values
  ('Água', 500, 1),
  ('Gelo de coco', 500, 2),
  ('Gelo de água', 300, 3),
  ('Red Bull', 1500, 4),
  ('Coca-Cola', 700, 5),
  ('Guaraná', 700, 6),
  ('Del Valle', 800, 7),
  ('Trident', 500, 8),
  ('Halls', 500, 9),
  ('Mentos', 500, 10),
  ('Trento', 800, 11),
  ('Fofura', 500, 12),
  ('Torcida', 500, 13)
) as v(name, price_cents, sort_order) on true
where c.name = 'Diversos'
and not exists (select 1 from public.products x where x.category_id = c.id and x.name = v.name);

insert into public.categories (name, description, sort_order)
select 'Cigarros', 'Venda somente para maiores de 18 anos', 7
where not exists (select 1 from public.categories where name = 'Cigarros');

insert into public.products (category_id, name, price_cents, sort_order)
select c.id, v.name, v.price_cents, v.sort_order
from public.categories c
join (values
  ('Rothmans', 1200, 1),
  ('Carlton', 2000, 2),
  ('Marlboro', 2000, 3),
  ('Gudang', 350, 4),
  ('Seda longa', 1000, 5),
  ('Seda pequena', 800, 6),
  ('Piteira', 600, 7),
  ('Bic', 1000, 8),
  ('Isqueiro', 700, 9),
  ('Rothmans (solto)', 100, 10),
  ('Carlton (solto)', 200, 11),
  ('Marlboro (solto)', 200, 12),
  ('Gudang (3 por R$ 10)', 1000, 13),
  ('Seda longa (solta)', 100, 14),
  ('Seda pequena (solta)', 50, 15),
  ('Piteira (solta)', 50, 16)
) as v(name, price_cents, sort_order) on true
where c.name = 'Cigarros'
and not exists (select 1 from public.products x where x.category_id = c.id and x.name = v.name);

insert into public.categories (name, description, sort_order)
select 'Narguilé', 'Consultar o sabor das essências no balcão', 8
where not exists (select 1 from public.categories where name = 'Narguilé');

insert into public.products (category_id, name, price_cents, sort_order)
select c.id, v.name, v.price_cents, v.sort_order
from public.categories c
join (values
  ('Aluguel de narguilé', 3000, 1),
  ('Troca de rosh', 2000, 2)
) as v(name, price_cents, sort_order) on true
where c.name = 'Narguilé'
and not exists (select 1 from public.products x where x.category_id = c.id and x.name = v.name);

-- Porções e lanches. Itens indisponíveis entram com is_available = false.

insert into public.categories (name, description, sort_order)
select 'Porções', null, 10
where not exists (select 1 from public.categories where name = 'Porções');

insert into public.products (category_id, name, price_cents, is_available, sort_order)
select c.id, v.name, v.price_cents, v.is_available, v.sort_order
from public.categories c
join (values
  ('Batata simples', 1600, true, 1),
  ('Batata com nugget', 3500, true, 2),
  ('Batata turbinada', 2500, true, 3),
  ('Batata calabresa', 3500, false, 4),
  ('Nugget', 3500, true, 5),
  ('Frango a passarinho', 4000, false, 6),
  ('Calabresa', 4000, false, 7)
) as v(name, price_cents, is_available, sort_order) on true
where c.name = 'Porções'
and not exists (select 1 from public.products x where x.category_id = c.id and x.name = v.name);

insert into public.categories (name, description, sort_order)
select 'Lanches', null, 11
where not exists (select 1 from public.categories where name = 'Lanches');

insert into public.products (category_id, name, price_cents, is_available, sort_order)
select c.id, v.name, v.price_cents, v.is_available, v.sort_order
from public.categories c
join (values
  ('Burguer salada', 2000, false, 1),
  ('Líder burguer', 1600, true, 2),
  ('Líder cheddar', 2100, true, 3)
) as v(name, price_cents, is_available, sort_order) on true
where c.name = 'Lanches'
and not exists (select 1 from public.products x where x.category_id = c.id and x.name = v.name);
